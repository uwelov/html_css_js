let x = 0;

function test(){
    x++;
    document.querySelector(".circle").style.marginLeft = x+"px";
    if(x==500){
       x=0;
       }
}

setInterval(test,1);