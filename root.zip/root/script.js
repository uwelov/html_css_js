let circle = document.querySelector(".circle").style;
circle.marginLeft = "0px";
circle.marginTop = "0px";
let x = 0 , y = 0;
function name(event){
    if (event.keyCode==39){
        x+=10;
        circle.marginLeft = x+"px";
    }
    else if (event.keyCode==37){
        x-=10;
        circle.marginLeft = x+"px";
    }
    else if(event.keyCode==40){
            y+=10;
            circle.marginTop = y+"px";
            }
    else if(event.keyCode==38){
            y-=10;
            circle.marginTop = y+"px";
    }
}

document.body.onkeydown = name;
