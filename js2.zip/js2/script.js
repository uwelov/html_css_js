let my_win = 0;
pc_win = 0;
let lvl = 1;
let pc_sub;
let str;
while (my_win < 3 && pc_win < 3) {
    let my_sub = prompt("select a subject: rock, scissors or paper");
    pc_sub = Math.round(Math.random() * 3);
    if (pc_sub == 1) {
        str = "rock";
    } else if (pc_sub == 2) {
        str = "scissors";
    } else {
        str = "paper";
    }

    console.log("------------------------lvl " + lvl + "------------------------")
    lvl++;
    if (my_sub == "rock") {
        if (str == "scissors") {
            console.log("you win");
            my_win++;
        } else if (str == "paper") {
            console.log("you lose");
            pc_win++;
        } else {
            console.log("lol");
            lvl--;
        }
    } else if (my_sub == "scissors") {
        if (str == "paper") {
            console.log("you win");
            my_win++;
        } else if (str == "rock") {
            console.log("you lose");
            pc_win++;
        } else {
            console.log("lol");
            lvl--;
        }
    } else if (my_sub == "paper") {
        if (str == "rock") {
            console.log("you win");
            my_win++;
        } else if (str == "scissors") {
            console.log("you lose");
            pc_win++;
        } else {
            console.log("lol");
            lvl--;
        }
    }
}
if (my_win > pc_win) {
    console.log("you winner")
} else {
    console.log("you loser");
}