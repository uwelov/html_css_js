let surname = prompt("Введите Вашу фамилию", "Бекетова");
let name = prompt("Введие Ваше имя", "Алиса");
let age = prompt("Введите Ваш возраст", "15");
console.log("Вас зовут " + surname + " " + name + ". Вам " + age + " лет.");