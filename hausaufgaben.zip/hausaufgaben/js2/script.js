let my_win = 0; pc_win = 0;
let lvl = 1;
let btn1 = document.querySelector(".sub1");
let btn2 = document.querySelector(".sub2");
let btn3 = document.querySelector(".sub3");
while(my_win<3 && pc_win<3){
    lvl++;
    
}