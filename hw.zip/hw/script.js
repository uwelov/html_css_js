function bgcolor(){
    let color = document.querySelector(".text");
    color.style.color="red";
}
document.querySelector(".text").onclick = bgcolor;